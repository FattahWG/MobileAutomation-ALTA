# SerenityBddAppium

To running the project, using mvn clean verify
